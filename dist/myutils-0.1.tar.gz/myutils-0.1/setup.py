from setuptools import setup

# or
# from distutils.core import setup

setup(
    name="myutils",  # 包名字
    version="0.1",  # 包版本
    description="",  # 简单描述
    author="",  # 作者
    author_email="",  # 作者邮箱
    url="",  # 包的主页
    packages=["myutils"],  # 包
)
